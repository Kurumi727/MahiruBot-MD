import fetch from 'node-fetch'

export async function before(m, { conn }) {
let img = await (await fetch(`https://qu.ax/abjz.jpg`)).buffer()

global.rcanal = {
 contextInfo: {
     	isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363335320736645@newsletter",
      serverMessageId: 100,
      newsletterName: namechannel,
   }, 
   externalAdReply: {
    showAdAttribution: true, 
    title: botname, 
    body: textbot, 
    mediaUrl: null, 
    description: null, 
    previewType: "PHOTO", 
    thumbnailUrl: "https://qu.ax/abjz.jpg", 
    sourceUrl: canal, 
    mediaType: 1, 
    renderLargerThumbnail: false }, 
    }, 
    }


/* global.rcanal = {
    contextInfo: {
    	isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363319490414132@newsletter",
      serverMessageId: 100,
      newsletterName: namechannel,
    },
    },
  }*/

 global.adReply = {
	    contextInfo: { 
             forwardingScore: 9999, 
                 isForwarded: false, 
                    externalAdReply: {
				    showAdAttribution: true,
					title: botname,
					body: textbot,
					mediaUrl: null,
					description: null,
					previewType: "PHOTO",
					thumbnailUrl: "https://qu.ax/TaXt.jpg",
                    thumbnail: img,
		           sourceUrl: canal,
		           mediaType: 1,
                   renderLargerThumbnail: true
				}
			}
		}
}