let handler = async (m, { conn, usedPrefix, isOwner }) => {
let txt_owner = "> _*`Hola, Este es el numero de mi creador, cualquier falla o si quieres agregar el bot a tu grupo, puedes hablarle`*_\n\n `+52 667 154 8329`"
await conn.sendFile(m.chat, "https://qu.ax/wuWc.jpg", 'thumbnail.jpg', txt_owner, m, null, rcanal)
}
handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator', 'creador', 'dueño'] 

export default handler